
<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
	
if(isset($_POST['submit']))
  {
  $folder="data/";


    $pdfdata = $_FILES['pdfdata']['name'];
	$pdfdata_loc = $_FILES['pdfdata']['tmp_name'];
	$new_pdfdata_name = strtolower($pdfdata);
	$final_pdfdata=str_replace(' ','-',$new_pdfdata_name);
	
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobileno=$_POST['mobile'];
    $pdfdata=$_POST['pdfdata'];
    $idedit=$_POST['editid'];

    if(move_uploaded_file($pdfdata_loc,$folder.$final_pdfdata))
		{
			$pdfdata=$final_pdfdata;
		}

	$sql="UPDATE users SET name=(:name), email=(:email), mobile=(:mobileno), pdfdata=(:pdfdata) WHERE id=(:idedit)";
	$query = $dbh->prepare($sql);
	$query-> bindParam(':name', $name, PDO::PARAM_STR);
	$query-> bindParam(':email', $email, PDO::PARAM_STR);
	$query-> bindParam(':mobileno', $mobileno, PDO::PARAM_STR);
	$query-> bindParam(':idedit', $idedit, PDO::PARAM_STR);
    $query-> bindParam(':pdfdata', $pdfdata, PDO::PARAM_STR);
	$query->execute();
	$msg="Information Updated Successfully";
} 

if (isset($_POST['submit']))
    {   
    ?>
<script type="text/javascript">
window.location = "./dashboard.php";
</script>      
    <?php
    }

?>

<?php require './includes/header.php';?>
<!-- body area -->
<?php
		$email = $_SESSION['alogin'];
		$sql = "SELECT * from users where email = (:email);";
		$query = $dbh -> prepare($sql);
		$query-> bindParam(':email', $email, PDO::PARAM_STR);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>


<div class="px-4 py-5 my-5 text-center">
    <h1 class="display-5 fw-bold">Classroom - <?php echo htmlentities($_SESSION['alogin']); ?>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?></h1>
    <div class="col-lg-6 mx-auto">
    <table class="table">
  <thead>
    <tr>
      <th scope="col">Name</th>
      <th scope="col">Phone</th>
      <th scope="col">Email</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><?php echo htmlentities($result->name);?></td>
      <td><?php echo htmlentities($result->mobile);?></td>
      <td><?php echo htmlentities($result->email);?></td>
    </tr>

  </tbody>
</table>
      <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
        <button type="button" class="btn btn-outline-secondary btn-lg px-4">Finserv</button>
        <button type="button" class="btn btn-outline-secondary btn-lg px-4">Tata</button>
      </div>
    </div>
  </div>

  <div class="px-4 py-5 my-5 text-center">
    <h1 class="display-5 fw-bold">Data</h1>
    <div class="col-lg-6 mx-auto">
    <div class="ratio ratio-16x9">
      <iframe src="./data/<?php echo htmlentities($result->pdfdata);?>" style="max-width:100%;height:500px;"></iframe>
    </div>
    </div>
  </div>






<?php require './includes/footer.php';?>
<?php } ?>