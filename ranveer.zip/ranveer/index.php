<?php
session_start();
include('includes/config.php');
if(isset($_POST['login']))
{   

$status='1';
$email=$_POST['username'];
$password=$_POST['password'];
$sql ="SELECT email,password FROM users WHERE email=:email and password=:password and status=(:status)";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> bindParam(':status', $status, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['alogin']=$_POST['username'];
echo "<script type='text/javascript'> document.location = 'dashboard.php'; </script>";
} else{
  
  echo "<script>alert('Invalid Details Or Account Not Confirmed');</script>";

}

}



?>

<?php require './includes/header.php';?>
<!-- Index area -->

<div class="container col-xl-10 col-xxl-8 px-4 py-5">
    <div class="row align-items-center g-lg-5 py-5">
      <div class="col-lg-7 text-center text-lg-start">
        <h1 class="display-4 fw-bold lh-1 mb-3">Login</h1>
        <p class="col-lg-10 fs-4">Enter Your Details to login to Classroom.</p>
      </div>
      <div class="col-md-10 mx-auto col-lg-5">
        <form method="post" class="p-4 p-md-5 border rounded-3 bg-light">
          <div class="form-floating mb-3">
            <input type="text" name="username" class="form-control mb" id="floatingInput" placeholder="name@example.com" required>
            <label for="floatingInput">Email address</label>
          </div>
          <div class="form-floating mb-3">
            <input type="password" name="password" class="form-control mb" id="floatingPassword" placeholder="Password" required>
            <label for="floatingPassword">Password</label>
          </div>
          <button class="w-100 btn btn-lg btn-primary" name="login" type="submit">Login</button>
          <hr class="my-4">
          <small class="text-muted">By clicking Login, you agree to the terms of use.</small>
        </form>
      </div>
    </div>
  </div>
		



<!-- Index area end -->

<?php require './includes/footer.php';?>