<?php
include('includes/config.php');
if(isset($_POST['submit']))
{



$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$mobileno=$_POST['mobileno'];


 
    
$sql ="INSERT INTO users(name,email, password, mobile, status) VALUES(:name, :email, :password, :mobileno, 1)";
$query= $dbh -> prepare($sql);
$query-> bindParam(':name', $name, PDO::PARAM_STR);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> bindParam(':mobileno', $mobileno, PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo "<script type='text/javascript'>alert('Registration Sucessfull!');</script>";
echo "<script type='text/javascript'> document.location = 'index.php'; </script>";
}
else 
{
$error="Something went wrong. Please try again";
}

}
?>

<?php require './includes/header.php';?>
<!-- Index area -->
<div class="container col-xl-10 col-xxl-8 px-4 py-5">
    <div class="row align-items-center g-lg-5 py-5">
      <div class="col-lg-7 text-center text-lg-start">
        <h1 class="display-4 fw-bold lh-1 mb-3">Add Employee</h1>
        <p class="col-lg-10 fs-4">Enter Employee Details to add them in classroom.</p>
      </div>
      <div class="col-md-10 mx-auto col-lg-5">
      <form method="post" class="p-4 p-md-5 border rounded-3 bg-light" enctype="multipart/form-data" name="regform" onSubmit="return validate();">
          <div class="form-floating mb-3">
            <input type="text" name="name" class="form-control" id="floatingInput" placeholder="name@example.com" required>
            <label for="floatingInput">Name</label>
          </div>

          <div class="form-floating mb-3">
            <input type="text" name="email" class="form-control" id="floatingInput" placeholder="name@example.com" required>
            <label for="floatingInput">Email</label>
          </div>

          <div class="form-floating mb-3">
            <input type="number" name="mobileno" class="form-control" id="floatingInput" placeholder="name@example.com" required>
            <label for="floatingInput">Phone no.</label>
          </div>

          <div class="form-floating mb-3">
            <input type="password" name="password" class="form-control mb" id="floatingPassword" placeholder="Password" required>
            <label for="floatingPassword">Password</label>
          </div>
          <button class="w-100 btn btn-lg btn-primary" name="submit" type="submit">Register</button>
          <hr class="my-4">
          <small class="text-muted">By clicking Register, you agree to the terms of use.</small>
        </form>
      </div>
    </div>
  </div>




<!-- Index area end -->

<?php require './includes/footer.php';?>