<div class="brand clearfix">
<h4 class="pull-left text-white" style="margin:20px 0px 0px 20px">&nbsp; Admin Panel</h4>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#"> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="../index.php">Login Employee Panel</a></li>
				</ul>
			</li>
		</ul>
	</div>
