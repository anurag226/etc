	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				
			<li><a href="panel.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li><a href="../register.php"><i class="fa fa-user-plus"></i>Add Employee</a>
			</li>
			<li><a href="userlist.php"><i class="fa fa-users"></i>Employee list</a>
			</li>
			<li><a href="notification.php"><i class="fa fa-bell"></i> &nbsp;Notification <sup style="color:red">*</sup></a>
			</li>
			<li><a href="deleteduser.php"><i class="fa fa-user-times"></i> &nbsp;Deleted Employee</a>
			</li>
			<li><a href="logout.php"><i class="fa fa-user-times"></i> &nbsp;logout</a>
			</li>
			</ul>
		</nav>

		