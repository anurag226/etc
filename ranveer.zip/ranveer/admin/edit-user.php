<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{

if(isset($_GET['edit']))
	{
		$editid=$_GET['edit'];
	}


	
    if(isset($_POST['submit']))
    {
      $folder="../data/";


      $pdfdata = $_FILES['pdfdata']['name'];
    $pdfdata_loc = $_FILES['pdfdata']['tmp_name'];
    $new_pdfdata_name = strtolower($pdfdata);
    $final_pdfdata=str_replace(' ','-',$new_pdfdata_name);
    
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobileno=$_POST['mobile'];
      $pdfdata=$_POST['pdfdata'];
      $idedit=$_POST['editid'];
  
      if(move_uploaded_file($pdfdata_loc,$folder.$final_pdfdata))
      {
        $pdfdata=$final_pdfdata;
      }
  
    $sql="UPDATE users SET name=(:name), email=(:email), mobile=(:mobileno), pdfdata=(:pdfdata) WHERE id=(:idedit)";
    $query = $dbh->prepare($sql);
    $query-> bindParam(':name', $name, PDO::PARAM_STR);
    $query-> bindParam(':email', $email, PDO::PARAM_STR);
    $query-> bindParam(':mobileno', $mobileno, PDO::PARAM_STR);
    $query-> bindParam(':idedit', $idedit, PDO::PARAM_STR);
      $query-> bindParam(':pdfdata', $pdfdata, PDO::PARAM_STR);
    $query->execute();
    $msg="Information Updated Successfully";
  }    
  ?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>Edit Employee</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">

	<style>
.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
	background: #dd3d36;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
	background: #5cb85c;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.img-fluid {
    max-width: 100%;
    height: auto;
}
		</style>
</head>
<body>
<?php
		$sql = "SELECT * from users where id = :editid";
		$query = $dbh -> prepare($sql);
		$query->bindParam(':editid',$editid,PDO::PARAM_INT);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						
						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
									<div class="panel-heading">Edit Info</div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

									<div class="panel-body">

<!-- Form -->
<form method="post" class="form-horizontal" enctype="multipart/form-data">

    <legend>Edit User : <?php echo htmlentities($result->name); ?></legend>
    <div class="mb-3">
      <label class="form-label">Name</label>
      <input type="text" name="name" class="form-control" required value="<?php echo htmlentities($result->name);?>">
    </div>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="text"name="email" class="form-control" required value="<?php echo htmlentities($result->email);?>">
    </div>
    <div class="mb-3">
      <label class="form-label">Phone No.</label>
      <input type="text" name="mobile" class="form-control" required value="<?php echo htmlentities($result->mobile);?>">
    </div><br />
    <div class="mb-3">
    <label for="formFile" class="form-label">Upload Data</label>
    <br />
    <input type="file" name="pdfdata" class="form-control">Pdf<br>
  </div>









<!--  -->
    <input type="hidden" name="editid" class="form-control" required value="<?php echo htmlentities($result->id);?>">
<!--  --><br />
<button class="btn btn-primary" name="submit" type="submit">Save Changes</button>
</form>
<!-- End Form -->





	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
	<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					});
	</script>

</body>
</html>
<?php } ?>